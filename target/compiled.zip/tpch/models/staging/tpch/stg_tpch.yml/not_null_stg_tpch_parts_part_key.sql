
    
    



select part_key
from ANALYTICS.dbt_mwan.stg_tpch_parts
where part_key is null


