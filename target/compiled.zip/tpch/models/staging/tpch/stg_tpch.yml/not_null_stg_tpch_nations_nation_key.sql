
    
    



select nation_key
from ANALYTICS.dbt_mwan.stg_tpch_nations
where nation_key is null


