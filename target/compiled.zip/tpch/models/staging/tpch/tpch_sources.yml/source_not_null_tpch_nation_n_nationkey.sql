
    
    



select n_nationkey
from raw.tpch_sf001.nation
where n_nationkey is null


