
    
    



select o_orderkey
from raw.tpch_sf001.orders
where o_orderkey is null


