
    
    



select part_key
from ANALYTICS.dbt_mwan.dim_parts
where part_key is null


