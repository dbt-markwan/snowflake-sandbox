




select * from ANALYTICS.dbt_mwan.stg_tpch_orders where total_price < 0

