
    
    



select order_key
from ANALYTICS.dbt_mwan.fct_orders
where order_key is null


