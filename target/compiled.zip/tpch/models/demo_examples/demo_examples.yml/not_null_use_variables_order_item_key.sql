
    
    



select order_item_key
from ANALYTICS.dbt_mwan.use_variables
where order_item_key is null


