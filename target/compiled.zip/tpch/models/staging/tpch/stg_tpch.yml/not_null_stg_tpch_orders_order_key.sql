
    
    



select order_key
from ANALYTICS.dbt_mwan.stg_tpch_orders
where order_key is null


