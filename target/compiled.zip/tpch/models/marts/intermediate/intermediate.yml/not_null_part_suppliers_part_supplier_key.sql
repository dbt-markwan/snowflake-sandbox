
    
    



select part_supplier_key
from ANALYTICS.dbt_mwan.part_suppliers
where part_supplier_key is null


