
    
    



select region_key
from ANALYTICS.dbt_mwan.stg_tpch_regions
where region_key is null


