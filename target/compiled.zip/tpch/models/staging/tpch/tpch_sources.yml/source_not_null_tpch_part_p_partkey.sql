
    
    



select p_partkey
from raw.tpch_sf001.part
where p_partkey is null


