




select * from ANALYTICS.dbt_mwan.stg_tpch_suppliers where account_balance < 0

