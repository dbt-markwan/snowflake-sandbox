
    
    



select c_custkey
from raw.tpch_sf001.customer
where c_custkey is null


