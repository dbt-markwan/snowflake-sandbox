
    
    



select customer_key
from ANALYTICS.dbt_mwan.materialization_incremental
where customer_key is null


