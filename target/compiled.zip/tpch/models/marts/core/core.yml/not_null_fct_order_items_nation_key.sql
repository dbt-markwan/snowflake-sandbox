
    
    



select nation_key
from ANALYTICS.dbt_mwan.fct_order_items
where nation_key is null


