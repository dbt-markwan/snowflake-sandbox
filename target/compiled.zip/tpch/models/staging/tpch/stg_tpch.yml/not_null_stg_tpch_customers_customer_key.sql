
    
    



select customer_key
from ANALYTICS.dbt_mwan.stg_tpch_customers
where customer_key is null


