
    
    



select r_regionkey
from raw.tpch_sf001.region
where r_regionkey is null


