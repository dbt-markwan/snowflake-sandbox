

with orders as ( select * from ANALYTICS.dbt_mwan.stg_tpch_orders )

select *
from   orders 
where  total_price < 0