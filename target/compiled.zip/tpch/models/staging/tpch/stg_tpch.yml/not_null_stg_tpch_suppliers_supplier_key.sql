
    
    



select supplier_key
from ANALYTICS.dbt_mwan.stg_tpch_suppliers
where supplier_key is null


