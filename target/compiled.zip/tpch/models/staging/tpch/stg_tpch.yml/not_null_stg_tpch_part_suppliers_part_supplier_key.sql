
    
    



select part_supplier_key
from ANALYTICS.dbt_mwan.stg_tpch_part_suppliers
where part_supplier_key is null


