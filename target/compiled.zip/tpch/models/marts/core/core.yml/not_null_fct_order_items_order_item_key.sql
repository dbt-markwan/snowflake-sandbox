
    
    



select order_item_key
from ANALYTICS.dbt_mwan.fct_order_items
where order_item_key is null


