
    
    



select order_item_key
from ANALYTICS.dbt_mwan.stg_tpch_line_items
where order_item_key is null


