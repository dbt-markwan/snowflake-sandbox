
    
    



select order_item_key
from ANALYTICS.dbt_mwan.order_items
where order_item_key is null


