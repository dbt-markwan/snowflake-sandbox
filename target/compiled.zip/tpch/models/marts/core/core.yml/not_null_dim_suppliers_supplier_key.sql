
    
    



select supplier_key
from ANALYTICS.dbt_mwan.dim_suppliers
where supplier_key is null


