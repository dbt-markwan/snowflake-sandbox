
    
    



select customer_key
from ANALYTICS.dbt_mwan.dim_customers
where customer_key is null


