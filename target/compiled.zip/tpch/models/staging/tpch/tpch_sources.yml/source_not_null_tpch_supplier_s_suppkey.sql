
    
    



select s_suppkey
from raw.tpch_sf001.supplier
where s_suppkey is null


